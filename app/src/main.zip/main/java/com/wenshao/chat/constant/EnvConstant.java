package com.wenshao.chat.constant;

/**
 * Created by wenshao on 2017/3/21.
 * 打包环境配置
 */

public class EnvConstant {
    // 当前环境  debug:本地开发  test:测试  pro:线上
    public final static String ENVIRONMENT = "debug";


}
