package com.wenshao.chat.exception;


/**
 * Created by wenshao on 2017/3/13.
 * 登陆状态异常
 */

public class LoginException extends Exception {
    public LoginException(String msg){
        super(msg);
    }
}
