package com.wenshao.chat.bean;

import com.wenshao.chat.util.JsonResponseParser;

import org.xutils.http.annotation.HttpResponse;

/**
 * Created by wenshao on 2017/4/16.
 * 文件上传返回对象
 */
@HttpResponse(parser = JsonResponseParser.class)
public class FileUploadData {
    private String filePath;

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
}
