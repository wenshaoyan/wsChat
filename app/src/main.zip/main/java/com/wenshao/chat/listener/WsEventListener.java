package com.wenshao.chat.listener;

/**
 * Created by wenshao on 2017/4/9.
 * WebSocket监听的事件
 */

public interface WsEventListener {
    // 重新连接
    void reconnect();
    // 聊天室新消息
    void newMessage(String str);

}
