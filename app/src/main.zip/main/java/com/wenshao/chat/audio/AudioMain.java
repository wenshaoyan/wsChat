package com.wenshao.chat.audio;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by wenshao on 2017/4/19.
 * 录音执行类
 */

public class AudioMain {
    private Timer timer;  // 计时器
    /**
     * 重新录音
     */
    public void restartRecording(){

    }
    /**
     * 开始录音
     */
    public void resumeRecording(){

    }

    /**
     * 暂停录音
     */
    public void pauseRecording(){

    }
    /**
     * 停止录音
     */
    public void stopRecording(){

    }

    /**
     * 开始播放
     */
    public void startPlaying(){

    }
    /**
     * 停止播放
     */
    public void stopPlaying(){


    }

    /**
     * 开始计时
     */
    private void startTimer(){
        stopTimer();
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                updateTimer();
            }
        }, 0, 1000);
    }

    /**
     * 停止计算
     */
    private void stopTimer(){
        if (timer != null) {
            timer.cancel();
            timer.purge();
            timer = null;
        }
    }

    /**
     * 更新计时器的显示
     */
    private void updateTimer(){

    }


}
